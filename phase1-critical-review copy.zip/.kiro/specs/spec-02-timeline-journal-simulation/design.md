# Spec 02 design — Marrow Journal, Simulation and Timeline

## Preconditions, owned implementation and boundaries

**Prerequisites (completed observable exit gates):** spec-01. **This spec owns:** `src/Marrow.Timeline`, shared canonical codec under `Marrow.Kernel`, `src/Marrow.Infrastructure` Timeline adapter, `tests/Marrow`. **Do not implement:** No finance/business rules, no game rule engine, no browser scrubber, no cross-domain event-payload classes.

**Consumes:** Public contracts from spec-01; inspect only their exported interfaces, named migrations and relevant tests. **Exposes:** The implemented behavior and stable public contract of this spec for downstream dependents. No spec may rewrite `Marrow.Timeline` public or `web/packages/timeline-ui` contracts without an approved cross-app ADR and dual-client test.

**Architecture authority:** `docs/architecture/01-master.md` defines dependency direction and state authority, `03-contracts.md` defines exact conceptual interfaces. This design defines this spec's *unique implementation ownership*; prefer whichever private class names fit the repo once validated, but preserve semantics. A superior nonbreaking local algorithm is allowed; shared ABI/persistence schema/version/security authority is not a local choice.

## Implementation strategy, contracts and data flow

### Contract authority and ordering

Implement the exact conceptual contract of `docs/architecture/03-contracts.md`; `spec-02` owns public C# signature realization and canonical serialization schema. `TimelinePosition(long)` nonnegative; sequences are contiguous. A `StepRecord<TInput>` has a step even if zero inputs. Within a step use `(Ordinal,InputId)` ordering, validate unique IDs and reject duplicate ordinal collision if payload conflicts. Revenue business-time metadata is **not** the source sort key. A stream is defined by immutable `HistoryManifest` domain, owner, rules/reducer/schema versions, seed/model refs, and input codec hash; this is stored at creation, not read from current app config later.

Design `IJournalStore` metadata/steps/checkpoint ports and a Postgres adapter; avoid one generic EF repository for domain aggregates. Append new source step + record-hash in a transaction with expected-last-position concurrency check; enforce immutable UPDATE/DELETE behavior via application role privileges or schema policies, database append-only triggers where necessary. Branch record stores `(branch_id,source_id,fork_position,operation_key,manifest)` and only its own suffix; prefix resolution is recursive reference read-only (bounded parent depth or flattened prefix manifest validation); maximum branch depth chosen and tested to prevent pathological scans. No N+1 per-tick DB round trips: page through range, use checkpoint every measured configurable N steps. Snapshot frequency is **configurable** with different domain policies (e.g., 30–150 game ticks target vs event count for finance); engine never defines universal 30Hz.

Canonical deterministic state: domain codec includes *all significant fields*, sorted dictionaries/sets and fixed integer representation or canonical decimal encoding. Hash SHA-256 of `(stateSchemaVersion || canonicalBytes)` distinct from a journal record hash-chain `H(previousHash || canonicalStepEnvelope)`; code versions and deterministic context included in source manifest verification. A restore against incompatible code fails closed rather than migrates silently. Replay comparisons are a domain-supplied pure projector and alignment mapping; the shared engine coordinates calls only.

### Transaction and side-effect safety

Reducers are pure, not injected with EF, timers, Redis or model services. Cancellation propagates at bounded intervals, persistence writes only manifest/steps/checkpoints/branch metadata; no domain business postings. A new fork inherits state at T by verified restoration; never copy partial live mutable state references. `ContinueAsync` writes successive steps and terminal verification atomically per batch with explicit `Incomplete|Verified|Failed` lifecycle; retries dedupe by input identity. A repair workflow may mark history invalid with an append-only audit record, never silently delete/alter source contents.

### Required two-reducer integration proof

Test adapter A: integer tick world with timer/cooldown/collected-ID set and **empty ticks**; adapter B: event-driven synthetic counter with nonuniform business timestamps and same-time different ordinals. Property tests generate seeds/input streams/fork T/sibling suffixes and assert prefix state hash equality and zero source mutation, including after cancellation. This checks **genericity**, not yet functional applications.

## Permissions, concurrency and failure rules

- Every publicly callable operation derives actor/session from verified server auth and uses the domain's ownership/membership/role policy; never trust a submitted principal ID.
- Retry behavior must distinguish idempotent retry from conflicting duplicate payload. A cancellation or unreachable dependency must leave prior durable authority intact and return visible error state.
- Persist state only in the owning module's schema and through frozen contracted ports. No direct cross-domain table mutation, no use of browser-rendered state as authority, no silent change to original source.
- Contract/rules/codec changes are versioned; emit readable incompatibility rather than secretly reinterpret historical data.

## Testing strategy (owned by this spec)

- FsCheck sequence: Restore(T).hash equals recorded checkpoint/replay at all T
- Original bytes, row count and journal chain unchanged after any sibling branch
- Missing/gapped/duplicated ordinal and wrong reducer/codec version => typed failure
- Concurrent same fork key => one branch; same key changed override => conflict
- Corrupted stored checkpoint causes explicit failure; cancellation leaves incomplete branch

## Specific implementation traps

- A syntactically present endpoint or view without real state transitions does not pass.
- Generic framework logic cannot embed money/game rules or clone the shared Timeline engine.
- Public interface changes require updating its producer, typed clients/consumers and corresponding architecture tests in the *same* compatible change, with ADR if consequential.

**Kiro model routing:** Strong reasoning for codec/contracts and immutable persistence; economical for local wiring.
