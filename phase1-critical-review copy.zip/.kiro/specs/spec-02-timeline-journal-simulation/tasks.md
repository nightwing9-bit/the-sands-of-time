# Spec 02 implementation tasks — Marrow Journal, Simulation and Timeline

**Execute tasks in listed order.** Dependencies: spec-01. Only check a box after actual changed files, tests and observed proof exist. Tasks are bounded work packages, **not AI chat prompts**. The user-supplied context is a requirements baseline, not permission to invent completed code. For actual code inspection, open the relevant named paths plus narrow dependent contract/migration/tests; follow a genuine dependency when discovered, but do not load the entire repo automatically.

## Ordered implementation tasks

- [ ] **2.1 Freeze codec and contract surface**
  - **Precondition/input & inspect:** `docs/architecture/03-contracts.md`, `src/Marrow.Kernel`, Marrow Timeline project. Completed prerequisite spec exit gate must already have evidence.
  - **Produce/modify:** real types/interfaces, canonical version tags, typed errors.
  - **Forbidden changes:** bank/game types or hidden DateTime.Now/Random. Do not change frozen shared public contracts without ADR.
  - **Verification:** compile contracts + cross-domain references check.
  - **Done when:** two test reducers compile against one interface.

- [ ] **2.2 Implement immutable store and migrations**
  - **Precondition/input & inspect:** `marrow_timeline` schema, migrations, Postgres adapter. Completed prerequisite spec exit gate must already have evidence.
  - **Produce/modify:** manifest/steps/checkpoint/fork tables, transaction append and immutability controls.
  - **Forbidden changes:** generic CRUD update/Delete for history. Do not change frozen shared public contracts without ADR.
  - **Verification:** real Postgres duplicate/gap/concurrent append, UPDATE denied.
  - **Done when:** append-only persisted steps verified.

- [ ] **2.3 Implement restore/replay/hash**
  - **Precondition/input & inspect:** transition/codec/checkpoint ports, test adapters. Completed prerequisite spec exit gate must already have evidence.
  - **Produce/modify:** nearest-checkpoint loading, deterministic fold, SHA-256 chain and explicit errors.
  - **Forbidden changes:** timestamp ordering or position-only snapshots. Do not change frozen shared public contracts without ADR.
  - **Verification:** FsCheck restore/replay across random sequences and corrupt codecs.
  - **Done when:** all valid positions reproduce recorded hashes.

- [ ] **2.4 Implement fork/continue/compare**
  - **Precondition/input & inspect:** branch metadata, source resolver, stable operation id. Completed prerequisite spec exit gate must already have evidence.
  - **Produce/modify:** readonly prefix, own suffix, idempotent forks, aligned projection.
  - **Forbidden changes:** copy-and-rewrite of original, business effects inside Timeline. Do not change frozen shared public contracts without ADR.
  - **Verification:** multiple sibling branches and cancel/retry tests.
  - **Done when:** branches are independently reproducible.

- [ ] **2.5 Cross-domain-shape proof and gate**
  - **Precondition/input & inspect:** tests/Marrow fake tick+event reducers, shared Assembly refs. Completed prerequisite spec exit gate must already have evidence.
  - **Produce/modify:** end-to-end Testcontainers proof, docs for domain adapter usage.
  - **Forbidden changes:** passing tests only from in-memory fake store. Do not change frozen shared public contracts without ADR.
  - **Verification:** clean DB full record/restore/fork/compare replay.
  - **Done when:** single engine works with both logical clocks.

## Spec exit verification (blocking)

One `Marrow.Timeline` assembly and real Postgres store pass both event-ordered and tick-ordered reducers, arbitrary valid T, hashes, branch isolation, corrupt history and cancellation checks.

Minimum proof includes successful targeted automated tests and relevant integration observation **actually performed**. Record real result paths, commands, commit IDs, encountered defects and measured Kiro credit use (if observable) in `docs/kiro-log.md`; if any check cannot run, mark blocker and leave task/spec incomplete. Do **not** infer a passing test from this document.
