# Spec 03 design — Identity, Realtime and reliable integration

## Preconditions, owned implementation and boundaries

**Prerequisites (completed observable exit gates):** spec-01, spec-02. **This spec owns:** `src/Marrow.Infrastructure` auth/transport/outbox components, `src/Hosts.*` DI, `tests/Integration`. **Do not implement:** No gameplay tick rules, bank-specific permission decisions, domain score calculation, cross-service microservice broker fleet.

**Consumes:** Public contracts from spec-01, spec-02; inspect only their exported interfaces, named migrations and relevant tests. **Exposes:** The implemented behavior and stable public contract of this spec for downstream dependents. No spec may rewrite `Marrow.Timeline` public or `web/packages/timeline-ui` contracts without an approved cross-app ADR and dual-client test.

**Architecture authority:** `docs/architecture/01-master.md` defines dependency direction and state authority, `03-contracts.md` defines exact conceptual interfaces. This design defines this spec's *unique implementation ownership*; prefer whichever private class names fit the repo once validated, but preserve semantics. A superior nonbreaking local algorithm is allowed; shared ABI/persistence schema/version/security authority is not a local choice.

## Implementation strategy, contracts and data flow

### Identity

`marrow_identity` owns principal/session, role/claim and token revocation primitives. The same shared infrastructure library also exposes thin ordered messaging and leaderboard read-cache **mechanics** (typed bounded message envelope and Redis sorted-set projection/rebuild helper), while case-comment moderation and game lobby chat, finance alert priorities and gameplay rating formulas remain app-owned. Use ASP.NET Core Identity for staff password, TOTP MFA on staff privileged finance actions, access JWT for API/hub and rotating hashed opaque refresh sessions in HttpOnly Secure SameSite cookies. CSRF/origin rules on cookie-authenticated writes. Seed distinct dev-only operator/supervisor users with noncommitted credentials and fail if production mode uses default secret. For games, issue signed HttpOnly remembered guest cookie + DB session/principal; guest roles do not inherit bank staff policies. Domain (Revenant/GhostLap) resolves actual action authorization/tenant/history owner; shared identity only supplies verified actor context and token/session mechanics. Guest identity can be recovered on refresh, banned/revoked, and is never inferred from client-submitted `ownerId`.

### Realtime

Define typed `RealtimeEnvelope` (schemaVersion, streamId, decimal sequence, eventId, serverUTC, kind, payload). Hub groups and subscribe/unsubscribe enforce owner/membership via domain auth; bounded message payloads and rate limits. A client reconnect fetches snapshot with most recent stream sequence and resumes, not assumes perfect SignalR delivery. Redis supports optional scale-out for **transport** and presence but is not authoritative for active room simulation. Until a lease/fence design exists `Realtime` deployment is one process/replica; fail deployment guard on replica count >1. Financial alerts can publish via outbox; active game room states come directly from authoritative game loop with ephemeral snapshots and durable result at finish.

### Outbox

Domain schema (Revenant/GhostLap) contains its own outbox table; shared library provides insert-with-UoW, claim/dispatch/retry, envelope schema and consumer inbox receipts; `FOR UPDATE SKIP LOCKED` batch claim. At-least-once relay via Redis Streams or in-process typed delivery with durable outbox cursor; transactionally inbox-deduped business effect. Retry jitter bounded, dead-letter diagnostics, crash-after-send and crash-after-apply tests mandatory. No distributed transaction or cross-schema FK. Keep user messages out of high-volume matching history store.

## Permissions, concurrency and failure rules

- Every publicly callable operation derives actor/session from verified server auth and uses the domain's ownership/membership/role policy; never trust a submitted principal ID.
- Retry behavior must distinguish idempotent retry from conflicting duplicate payload. A cancellation or unreachable dependency must leave prior durable authority intact and return visible error state.
- Persist state only in the owning module's schema and through frozen contracted ports. No direct cross-domain table mutation, no use of browser-rendered state as authority, no silent change to original source.
- Contract/rules/codec changes are versioned; emit readable incompatibility rather than secretly reinterpret historical data.

## Testing strategy (owned by this spec)

- Refresh token rotation replay rejected and old token revoked
- TOTP absence denies privileged staff operation
- Forged guest ownership or hub group subscription denied
- Postgres business commit + Redis outage => pending outbox delivered on recovery
- Crash after send and after consume => one inbox business effect
- Room scale=2 forbidden until an owner lease/fence ADR

## Specific implementation traps

- A syntactically present endpoint or view without real state transitions does not pass.
- Generic framework logic cannot embed money/game rules or clone the shared Timeline engine.
- Public interface changes require updating its producer, typed clients/consumers and corresponding architecture tests in the *same* compatible change, with ADR if consequential.

**Kiro model routing:** Strong for identity privilege and outbox transaction; economical for hub DTO plumbing.
