# Shared contracts and frozen invariants (architecture authority)

This is the one authoritative cross-module decision registry for exact **conceptual** contract shape; `spec-02` creates the corresponding compilable types. Private method names may vary but **semantics cannot** change without an ADR and dependent-spec compatibility review.

## Marrow Timeline API v1

```csharp
public readonly record struct TimelineId(Guid Value);
public readonly record struct BranchId(Guid Value);
public readonly record struct TimelinePosition(long Value); // >= 0; wire decimal string
public record HistoryManifest(TimelineId Id, string DomainId, string OwnerId,
  string InputSchemaVersion, string ReducerVersion, string StateSchemaVersion,
  string RulesHash, string SeedHash, long LastPosition, string FinalStateHash,
  TimelineId? ParentId, long? ForkPosition, string VerificationStatus);
public record StepRecord<TInput>(long Position, IReadOnlyList<OrderedInput<TInput>> Inputs);
public record OrderedInput<T>(string InputId, int Ordinal, T Payload);
public interface IDeterministicTransition<TState,TInput,TContext> {
  TState Apply(TState previous, long position, IReadOnlyList<OrderedInput<TInput>> inputs,
               TContext pinnedContext);
}
public interface IStateCodec<TState> {
  byte[] EncodeCanonical(TState state); TState Decode(ReadOnlySpan<byte> bytes);
}
public interface ITimelineStore<TInput> {
  // append-only, sequential steps; full checkpoints; idempotent input ids; no updates
}
public interface ITimelineEngine<TState,TInput,TContext> {
  Task<VerifiedState<TState>> RestoreAsync(TimelineId id,long position,CancellationToken ct);
  Task<VerifiedReplay<TState>> ReplayAsync(TimelineId id,CancellationToken ct);
  Task<BranchId> ForkAsync(TimelineId source,long forkPosition,string operationKey,
                            TContext pinnedBranchContext,CancellationToken ct);
  Task<VerifiedReplay<TState>> ContinueAsync(BranchId branch,
                IAsyncEnumerable<StepRecord<TInput>> postForkSteps,CancellationToken ct);
}
```

The engine is the **only** generic store/restore/fork/continue/comparison coordinator. A domain adapter builds reducers, interprets positions and computes domain-specific outcome comparisons. `ForkAsync` does NOT mutate its source and must be idempotent by `(owner, source, fork, operationKey)`. A `StepRecord` may have zero inputs, important for empty game ticks. Inputs within a step are sorted by ordinal then inputId under domain-owned stable action priority. Branch own suffix begins exactly after fork step; parent prefix is a read-only reference. Verify hashes/checkpoint completeness before accepting any verified replay status. Return explicit typed `NotFound`, `Forbidden` (checked by caller application), `InvalidPosition`, `IncompatibleVersion`, `CorruptHistory`, `Conflict`, `Cancelled` results rather than success with guessed defaults. `TContext` is immutable/version-pinned; do not capture local clock/network calls in reducers.

**Journal storage**: manifest; immutable ordered steps `(timeline_id,position)`; input identity `(timeline_id,input_id)`; checkpoints `(timeline_id,position,canonical_hash,bytes)`; branch parent/fork links. Storage codec and input serialization version per source; enforced monotonically with uniqueness and transaction isolation. Append always verifies expected previous position. Source hash chain over canonical record envelopes plus previous hash is distinct from *state hash*; both are retained. A verified source hash proves continuity, not external notarization.

## Security interfaces v1

`IActorContext` includes stable `SubjectId`, `PrincipalKind=Staff|Guest`, `TenantId?`, role/claims and authenticated status; domain authorization checks are `CanReadHistory(actor, history)` and command policy handlers. OwnerId from requests is never trusted. Staff: separate demo staff identities, rotating refresh cookie, access JWT, CSRF where cookie-authenticated and TOTP MFA for privileged actions. Guest: signed, remembered cookie with server-backed revocation/session, no registration forced; guest still needs authorization for owned histories and room membership. Explicit replay share tokens have revocation and expiry; **private is default**. Token/credentials never enter logs or committed files.

## Realtime envelope v1

`{ schemaVersion: 1, streamId, sequence: decimal-string, eventId, serverUtc, kind, payload }` with per-stream monotonic sequence. On gap/reconnection client fetches authoritative snapshot + current sequence and resubscribes; sequence numbers are not gameplay ticks. Realtime transport can repeat/drop messages; financial/event outcome authority resides in DB, match score authority in C# room loop. Consumers never rely on hub delivery for exactly-once business effects. Room owner is exactly one running loop on **one Realtime replica** for initial deployment.

## Outbox v1

`{ eventId, eventType, eventVersion, aggregateId, occurredUtc, payload, correlationId }` stored in the initiating module schema in the *same transaction* as business effect. Relay may retry; consumer inbox unique `(consumerId,eventId)`. Retry bounded exponential + dead-letter or operator-visible poison state. Dedupe boundary must include the same transaction as the consumer business write.

## Revenant domain contract v1

`PaymentIntent` immutable exogenous input (stable ID, sourceBank/account, destBank/account, `Money(currency, minorUnits)`, simulated truth label, eventTimeUtc, sequence, feature inputs); `Decision` derived screen/hold/reject/approve; `SettlementPosting` debit/credit entries, same-currency balanced per group; `PolicyRef` ('v7'/'v8', config hash, model artifact hash, feature schema hash); `FinanceProjectionState` complete balances, held reservations, payment statuses, feature windows, derived metrics and scenario clock. Versioned domain reducer advances **exogenous inputs**, not a feed of already-settled decisions. Policy v7/v8 differ by explicit threshold and/or decision rules. Commit ledger only through `Revenant` live processing; branch projector receives **no** live ledger write capability. USD synthetic Friday Ring first; other currencies represented exactly by integer minor units, no cross-currency conversion without explicit new rule.

## GhostLap domain contract v1

`GameRulesVersion=ghost-v1`, `LayoutVersion=arena-v1`, 30 ticks/second *target* and 2700 ticks per 90s match *initial default*. Stable game input `(tick,slot,sequence,moveX,moveY,requestBurst)`, with bounded values. `GameState` contains full current world (players pos/velocity/score/charge/Overlit deadline, pair cooldowns, active/collected candle IDs, pending actions, rules/layout/schedule/seed identifiers and needed RNG state). All deterministic coordinates use versioned fixed-point integer units; renderer may interpolate floating pixels but cannot score them. Source ghost trace is read-only historical projection, **not added to living-world actors**. Stable per-tick phase order: validate and sort slot inputs → move and compute authoritative distance score → expire/activate candle schedule → collect by stable candle ID and tie-break slot → contact pairs sorted by slot IDs → manual Burst first, then due auto-Burst (max one per owner/tick) → if terminal tick, finalize after tick effects. Candle active at `activate <= tick < expire`; completed tick 2700 is inspect-only fork boundary. A future rules change creates a new `GameRulesVersion` and retains old replay availability.

## Browser Timeline adapter v1

```ts
type TimelinePosition = string;  // decimal, never floating point
interface TimelineAdapter {
  sourceId: string; branchId?: string;
  bounds: {start: TimelinePosition; end: TimelinePosition};
  readOnly: boolean;
  getLabel(position: TimelinePosition): string;
  getMarkers(): {position:TimelinePosition;label:string}[];
  seek(position: TimelinePosition): Promise<VerifiedPreview>;
  fork(position: TimelinePosition, options: unknown, idempotencyKey:string): Promise<{branchId:string}>;
}
```

`unknown` stands for caller-provided **domain-specific options**, never a shared game/bank options schema. Shared component owns navigation, seek debounce/keyboard semantics, loading/incompatible/error state and disabled branch at invalid/final tick; domain adapters own rules, auth and visualization. Both products use same compiled package instance/source path; adapter files reside within each app.

## Change control

Only the owning spec or an explicit follow-on ADR may change a contract. Cross-domain breaking changes require compatibility review, generated DTO/client regeneration, architecture test and both end-to-end adapter tests. Never update only a producer or only a consumer. For targets like score coefficients/ML thresholds, pin a typed version and allow later **measured** tuning with a new version, not silent mutation.
