# A. Phase 1 master architecture — The Sands Of Time

## 1. Decisions and evaluated alternatives

**Selected:** a single-repository **modular monolith** with domain-owned persistence, three executable host configurations (**API**, **Realtime**, **Worker**), one shared generic Marrow Timeline implementation, and independent Revenant/GhostLap domain adapters. **No domain gets to translate the other domain's types.** At initial deployment keep a **single Realtime replica** and thus one in-process authoritative owner per active room. Scale-out is disallowed without a new owner-election/affinity decision.

**Evaluated dependency decompositions:** (A) infrastructure/platform first, then complete finance, then complete game: easy module batching but keeps shared Timeline and second-adapter integration unproven until late; rejected. (B) four baskets with a small foundation, **two early vertical slices** through the same Timeline, then the hard per-domain completeness specs: slightly more cross-domain coordination but rapidly reveals wrong common abstractions and provides recorded proof milestones; selected. A third alternative, game-first single-app architecture refactored to a library afterward, was rejected because extractive refactoring would spend credits rewriting history and security contracts.

**13 specs / four baskets:** B1 four platform specs; B2 two first vertical slices; B3 three Revenant completion specs; B4 four Ghost Lap completion specs. Two apps get actual working branch paths at B2 gates, *before* secondary workflows. B2 is not a wireframe/stub milestone: it uses a real pure domain transition kernel. B3/4 add persistence, transport, ML, social and complete UI against those frozen contracts.

## 2. Physical project map (chosen minimum)

```text
src/Marrow.Kernel/                 (Results, IDs, deterministic serializations)
src/Marrow.Timeline/               (one restore/replay/fork/compare engine + journal port)
src/Marrow.Infrastructure/         (Postgres journal/outbox, Redis transport, identity/realtime building blocks)
src/Revenant.Contracts/            (public DTOs and integration events)
src/Revenant/                      (pure finance kernel, application, persistence, worker adapters)
src/GhostLap.Contracts/            (public DTOs and integration events)
src/GhostLap/                      (fixed-tick rules, solo/multiplayer/application/persistence)
src/Hosts.Api/                     (composition root, API, auth endpoints)
src/Hosts.Realtime/                (SignalR, sole room/tick loop owner)
src/Hosts.Worker/                  (outbox relay, bank scenarios, forecasts, replay jobs)
web/packages/contracts/            (OpenAPI-generated DTOs + versioned hub clients)
web/packages/timeline-ui/          (one generic React Timeline scrubber)
web/apps/revenant/                 (Revenant React UI / screens)
web/apps/ghost-lap/                (Ghost Lap React + PixiJS UI)
tests/{Architecture,Marrow,Revenant,GhostLap,Integration,E2E}/
deploy/{compose,nginx}/
scripts/checks/                    (cheap, deterministic shell checks)
.kiro/{specs,steering,settings,hooks}/
docs/{architecture,workflow,adr}/
```

A folder may hold subnamespaces instead of one C# project per logical layer. `*.Contracts` are small public assemblies. No cross-domain EF model reuse, shared Money/GameState, “universal event bus” framework, MediatR dependency by default, or production-grade cloud fleet.

## 3. Legal dependency graph

```text
Hosts.Api / Hosts.Realtime / Hosts.Worker (DI composition only)
    ├── Marrow.Infrastructure ──> Marrow.Timeline ──> Marrow.Kernel
    ├── Revenant ──> Revenant.Contracts ──> Marrow.Kernel (+ Marrow.Timeline)
    └── GhostLap ──> GhostLap.Contracts ──> Marrow.Kernel (+ Marrow.Timeline)
web/apps/* ──> web/packages/contracts + web/packages/timeline-ui
```

`Marrow.Timeline` does **not** reference either domain; domain assemblies do **not** import each other; domain rules do not import SignalR, Postgres, browser, PixiJS or React. Infrastructure may implement domain-owned repository ports in the domain assembly **only where needed**; the host wires concrete implementations. Cross-module interactions are explicit command/query interfaces (synchronous in same host when needed), or local transaction outbox to reliable asynchronous consumers. **No direct foreign schema reads/writes** for integration; Postgres schemas separate (`marrow_identity`, `marrow_timeline`, `revenant`, `ghostlap`). Identity owns principals; each domain owns resource authorization decisions.

## 4. State authority and transactions

| Authority | Writer/owner | Read/transport | Failure contract |
|---|---|---|---|
| Historical source + checkpoints | Marrow Timeline append API, with caller domain validation | immutable snapshots/records with source+owner and hash | version mismatch => fail closed, never reinterpret using current rules |
| Financial payment, journal group and balance | Revenant, one Postgres transaction | Revenant projections, outbox | rollback all postings on any unbalance/insufficient funds; retry bounded transient errors |
| Financial counterfactual | Revenant pure sandbox projector via Worker | branch-only result tables + metrics | never expose ledger repository to branch runner; cancellation doesn't change original |
| Game live match state | exactly one Realtime host room loop | signed/typed server snapshots via SignalR | stale inputs rejected; disconnect yields neutral controls, then explicit forfeit |
| Solo original and branch | GhostLap + shared journal port; original append-only | permission-checked history/replay API | save receipt only after DB commit; retry dedupes |
| Match rating | GhostLap durable `match_result`+`rating_effect` | Postgres authoritative rating; Redis sorted-set read cache | UNIQUE match/player effects, consumers may replay safely |
| Account/session | Marrow Identity policy + domain handlers | JWT/HTTP-only refresh cookies/guest session | deny unauthorized or expired access; never grant owner rights by submitted owner ID |

**Outbox:** insert the domain-owned outbox row in the same transaction as the business write; Worker relays at least once via Redis Streams (or direct typed handler initially), and consumer dedupes by `(eventId, consumerId)` stored with the business transaction. No “exactly once delivery” claim. Redis backplane is transport, not durable session authority. Chat messages use their own domain policies/rate limits, not a scoring side effect.

## 5. Deterministic replay: common meaning, distinct clocks

`TimelinePosition` is an unsigned/nonnegative 64-bit *logical step index*, serialized as a **decimal string at browser boundaries**. GhostLap has **one step per game tick**, including no-input ticks; Revenant has **one step per causally ordered exogenous payment/action input**, tagged with separate business timestamp. Source records contain stable `ordinal`/`inputId` tie-breaker and domain context/version identity. Do not reorder by wall-clock timestamps. Shared engine accepts a deterministic domain reducer plus a snapshot codec and a comparison projector. Domain pure reducers own all rules.

**Write/restore:** canonical byte encoding and state hash (SHA-256) over **all simulation-significant fields**, pinned reducer/rules/schema/seed/model metadata. Persist checkpoint at position 0 and configured intervals; to restore at T, load nearest checkpoint <=T and sequentially fold records to T. Fail closed on missing gaps, codec/version mismatch, or hash mismatch. Branch metadata points to immutable parent/prefix through T; its own post-T records start at T+1. Never copy and rewrite the source. Failed/cancelled branch is marked as failed/incomplete and cannot masquerade as verified.

**Finance-specific subtlety:** stored source *decisions* are not exogenous payment inputs. Pin the input facts and external commitments, then recompute policy-dependent decisions, holds, settlement and liquidity in the branch; preserve evidence of the original decisions separately. Otherwise policy v8 “replay” would just play policy v7 outcomes again. Original financial replay verifies source hashes using pinned v7 decisions/artifacts; alternate branch uses v8 and the same *upstream facts* (not the same outcomes). Any consequential human action after fork must be represented by a defined deterministic continuation rule, or make replay input incomplete and reject it rather than silently guessing.

**Game-specific subtlety:** precompute a candle schedule from a versioned seed and layout independent of player pickup behavior. Full snapshots include score/charge/cooldowns/Overlit timers/collection IDs/schedule/RNG and position/velocity. Ghost reads the *old* source projection, current world independently collects its own candles. Original source remains immutable.

## 6. Stable frontend/realtime boundaries

React `web/packages/timeline-ui` owns one functional scrubber with `sourceId`, selected decimal-string position, range, play/pause/seek/branch controls, verified source marker and comparison-selection callbacks; adapters map positions to tick labels or financial timestamps and render their own charts/scenes. Scrubber **never** computes scores, policy decisions, or authoritative states. Browser UI consumes generated REST DTOs and explicit typed hub messages (`schemaVersion`, `messageId`, `streamSequence`, `serverTime`, `payload`) with gap recovery via snapshot/refetch. Unknown critical schema versions fail gracefully.

## 7. Earliest real integration proof

After spec-02, run Marrow contract tests against two **tiny fake reducers only in tests** to prove genericity. Spec-05 brings a real six-bank deterministic financial input stream, pure payment/hold/settlement decisions, paired v7/v8 run and nonmutation hash. Spec-06 brings a real game greybox loop, 90s solo original, save/restore/fork and ghost trace. **Gate B2:** same `Marrow.Timeline` assembly and `timeline-ui` package demonstrably called by both; original hashes unchanged, game branch at tick with nonzero charge/pickup remains intact, bank alternate net balance/held outcome changes. This is the first demo-critical proof, not something to postpone to UI polish.

## 8. Versioning and rollout

Contracts carry explicit schema version; historical reducer/rules/policy/ML artifacts are immutable referenced by content hash. A backwards-compatible API additive field is okay with regenerated web client + consumer checks. Replay-significant changes require a *new* reducer/rules identifier or a migration that proves old hashes. Missing old reducer => display **incompatible/unavailable**; never silently replay with a newer reducer. PostgreSQL migrations are forward-only, owned by each schema, and exercised on a clean database and upgrade path. Deploy Compose single instance with separate API/Realtime/Worker process configs and HTTPS proxy; AWS Lightsail/EC2 after local proof; no claim that a Redis backplane makes two authoritative realtime instances safe.

## 9. Hard prohibitions

No final art in Phase 1; no third app; no multiplayer permanent archives; no real-money operations; no 100x/30Hz/performance claims without actual measurements. Do not alter the supplied demo narrative. Do not delete social/spectator/rating/mobile/ML scope simply because the central moment gets priority; each has an implementation owner in the DAG.
